using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace lab13.Views.Quiz
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
